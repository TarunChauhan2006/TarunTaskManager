from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from database import Base, engine

from routers.auth import router as auth_router
from routers.tasks import router as tasks_router
from routers.users import router as users_router


# Create database tables
Base.metadata.create_all(
    bind=engine
)


app = FastAPI(
    title="Tarun Task Manager API",
    description="Full Stack Task Management Application",
    version="2.0.0"
)


# CORS Configuration
app.add_middleware(
    CORSMiddleware,

    allow_origins=[
        # Vercel frontend
        "https://tarun-task-manager.vercel.app",

        # Render frontend
        "https://tarun-task-manager-frontend.onrender.com",

        # Local development
        "http://localhost:5173",
        "http://127.0.0.1:5173",
    ],

    allow_credentials=True,

    allow_methods=["*"],

    allow_headers=["*"],
)


# Routers
app.include_router(
    auth_router
)

app.include_router(
    tasks_router
)

app.include_router(
    users_router
)


# Root endpoint
@app.get("/")
def root():
    return {
        "message": "Tarun Task Manager API 🚀",
        "version": "2.0.0"
    }


# Health endpoint
@app.get("/health")
def health():
    return {
        "status": "healthy"
    }